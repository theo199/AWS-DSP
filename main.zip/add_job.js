exports.addJob = async (event, context) => {
  try {
    // Récupérer les données du job depuis l'événement
    const { job_type, content } = JSON.parse(event.body);

    // Traiter le job en fonction de son type
    if (job_type === 'addToS3') {
      // Effectuer l'opération d'ajout à S3
      // ...
      const response = {
        statusCode: 200,
        body: 'Job addToS3 traité avec succès',
      };
      return response;
    } else if (job_type === 'addToDynamoDB') {
      // Effectuer l'opération d'ajout à une autre table DynamoDB
      // ...
      const response = {
        statusCode: 200,
        body: 'Job addToDynamoDB traité avec succès',
      };
      return response;
    } else {
      const response = {
        statusCode: 400,
        body: 'Type de job non pris en charge',
      };
      return response;
    }
  } catch (error) {
    console.error('Une erreur s\'est produite :', error);
    const response = {
      statusCode: 500,
      body: 'Une erreur s\'est produite lors du traitement du job',
    };
    return response;
  }
};
